package com.cg.pagebean;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPageBean {
	WebDriver driver;
	
	//identify element
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement pfUname;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement pfPassword;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement pfCPassword;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement pfFname;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement pfLname;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[6]/td[1]")
	@CacheLookup
	WebElement pfGender;

	@FindBy(id="DOB")
	@CacheLookup
	WebElement pfDOB;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement pfEmail;
	@FindBy(id="txtAddress")
	@CacheLookup
	WebElement pfAddress;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[10]/td[1]")
	@CacheLookup
	WebElement pfCity;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement pfPhone;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[1]")
	@CacheLookup
	List<WebElement> pfHobbies;
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement pfSubmit;
	
	@FindBy(name="reset")
	@CacheLookup
	WebElement pfReset;
	
    public RegisterPageBean(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Setters Method
	public void setPfUname(String sUname) {
		pfUname.sendKeys(sUname);
	}

	public void setPfPassword(String sPassword) {
		pfPassword.sendKeys(sPassword);
	}

	public void setPfCPassword(String sCPassword) {
		pfCPassword.sendKeys(sCPassword);
	}

	public void setPfFname(String sFname) {
		pfFname.sendKeys(sFname);
	}

	public void setPfLname(String sLname) {
		pfLname.sendKeys(sLname);
	}

	public void setPfGender(String sGender) {
		pfGender.sendKeys(sGender);
	}

	public void setPfDOB(String sDOB) {
		pfDOB.sendKeys(sDOB);
	}

	public void setPfEmail(String sEmail) {
		pfEmail.sendKeys(sEmail);;
	}

	public void setPfAddress(String sAddress) {
		pfAddress.sendKeys(sAddress);
	}

	public void setPfCity(String sCity) {
		pfCity.sendKeys(sCity);
	}

	public void setPfPhone(String sPhone) {
		pfPhone.sendKeys(sPhone);
	}

	public void setPfHobbies() {
		for (WebElement var : pfHobbies) {
			var.click();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void setPfSubmit() {
		pfSubmit.click();
	}

	public void setPfReset() {
		pfReset.click();
	}
	
	//Getters Method
	public WebElement getPfUname() {
		return pfUname;
	}

	public WebElement getPfPassword() {
		return pfPassword;
	}

	public WebElement getPfCPassword() {
		return pfCPassword;
	}

	public WebElement getPfFname() {
		return pfFname;
	}

	public WebElement getPfLname() {
		return pfLname;
	}

	public WebElement getPfGender() {
		return pfGender;
	}

	public WebElement getPfDOB() {
		return pfDOB;
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public WebElement getPfAddress() {
		return pfAddress;
	}

	public WebElement getPfCity() {
		return pfCity;
	}

	public WebElement getPfPhone() {
		return pfPhone;
	}

	public List<WebElement> getPfHobbies() {
		return pfHobbies;
	}

	public WebElement getPfSubmit() {
		return pfSubmit;
	}

	public WebElement getPfReset() {
		return pfReset;
	}
	
}
