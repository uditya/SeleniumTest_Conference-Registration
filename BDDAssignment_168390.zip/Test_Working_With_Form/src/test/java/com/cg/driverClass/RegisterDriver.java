package com.cg.driverClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegisterDriver {
	static WebDriver driver=null;
	static String alertMessage=null;

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\abc\\"+"chromedriver.exe");
		driver=new ChromeDriver();
		
		driver.get("file:///D:/register%20page/WorkingWithForms.html");
		
		String title=driver.getTitle();
		System.out.println("The page title is :" + title);
		
		//for blank password
		driver.findElement(By.id("txtPassword")).sendKeys(" ");
		driver.findElement(By.name("submit")).click(); Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
		
		//for blank cpassword
		driver.findElement(By.id("txtConfPassword")).sendKeys(" ");
		driver.findElement(By.name("submit")).click(); Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
		
		//for invalid password
		driver.findElement(By.id("txtPassword")).sendKeys("uditya");
		driver.findElement(By.name("submit")).click();Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
		
		//for invalid cpassword
		driver.findElement(By.id("txtConfPassword")).sendKeys("ravi");
		driver.findElement(By.name("submit")).click();Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
		
		//for valid passwords
		driver.findElement(By.id("txtPassword")).sendKeys("uditya");
		driver.findElement(By.id("txtConfPassword")).sendKeys("uditya");
		driver.findElement(By.name("submit")).click();Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
		
		//for invalid passwords
		driver.findElement(By.id("txtPassword")).sendKeys("uditya");
		driver.findElement(By.id("txtConfPassword")).sendKeys("ravi");
		driver.findElement(By.name("submit")).click();Thread.sleep(1000);
		callAlert();
		Thread.sleep(1000);
	}

	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		System.out.println("driver alert message is :"+alertMessage);	

	}
}
