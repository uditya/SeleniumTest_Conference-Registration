package com.cg.stepdef;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagebean.RegisterPageBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStepDef {
	
	private WebDriver driver;
	private RegisterPageBean objRPB;
	
	@Before
	public void openBrowsser() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\abc\\"+"chromedriver.exe");	
		driver = new ChromeDriver();
		}
	
	@Given("^User is on Email Registration Page$")
	public void user_is_on_Email_Registration_Page() throws Throwable {
	    objRPB=new RegisterPageBean(driver);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get("file:///D:/register%20page/WorkingWithForms.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    String title=driver.getTitle();
	    if(title.contentEquals("Email Registration Form")) System.out.println("************************Title Matched");
	    else System.out.println("******************title not matched");
	    driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	    objRPB.setPfPassword("12345");
	    objRPB.setPfCPassword("12345");
	    objRPB.setPfSubmit();
	}

	@Then("^print success$")
	public void print_success() throws Throwable {
	    String alert=driver.switchTo().alert().getText();
	    driver.switchTo().alert().accept();
	    System.out.println("alert message is :"+alert);
	}

	@When("^user enter wrong details$")
	public void user_enter_wrong_details() throws Throwable {
	    objRPB.setPfPassword("uditya");
	    objRPB.setPfCPassword("12343");
	    objRPB.setPfSubmit();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alert=driver.switchTo().alert().getText();
	    driver.switchTo().alert().accept();
	    System.out.println("alert message is :"+alert);
	}


}
